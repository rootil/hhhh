import { VehicleType } from '../types/booking';

export const vehicles: VehicleType[] = [
  {
    id: 'sedan-standard',
    name: 'Standard Sedan',
    category: 'standard',
    capacity: {
      passengers: 4,
      luggage: 2
    },
    features: ['Air conditioning', 'Free WiFi', 'Complimentary water', 'Professional driver'],
    pricePerKm: 8,
    basePrice: 150,
    image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    id: 'mercedes-c-class',
    name: 'Mercedes C-Class',
    category: 'luxury',
    capacity: {
      passengers: 4,
      luggage: 3
    },
    features: ['Air conditioning', 'Free WiFi', 'Complimentary water', 'Leather seats', 'Premium audio system', 'Professional driver'],
    pricePerKm: 15,
    basePrice: 300,
    image: 'https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    id: 'skoda-kodiaq',
    name: 'Skoda Kodiaq SUV',
    category: 'premium',
    capacity: {
      passengers: 7,
      luggage: 5
    },
    features: ['Air conditioning', 'Free WiFi', 'Complimentary water', 'Spacious interior', 'All-wheel drive', 'Professional driver'],
    pricePerKm: 12,
    basePrice: 250,
    image: 'https://images.pexels.com/photos/1719648/pexels-photo-1719648.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    id: 'premium-van',
    name: 'Premium Van',
    category: 'premium',
    capacity: {
      passengers: 8,
      luggage: 6
    },
    features: ['Air conditioning', 'Free WiFi', 'Complimentary water', 'Extra luggage space', 'Comfortable seating', 'Professional driver'],
    pricePerKm: 12,
    basePrice: 250,
    image: 'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    id: 'luxury-mercedes-sedan',
    name: 'Mercedes Luxury Sedan',
    category: 'luxury',
    capacity: {
      passengers: 4,
      luggage: 3
    },
    features: ['Air conditioning', 'Free WiFi', 'Complimentary water', 'Leather seats', 'Premium sound system', 'Sunroof', 'Professional driver'],
    pricePerKm: 18,
    basePrice: 350,
    image: 'https://images.pexels.com/photos/3802508/pexels-photo-3802508.jpeg?auto=compress&cs=tinysrgb&w=800'
  }
];