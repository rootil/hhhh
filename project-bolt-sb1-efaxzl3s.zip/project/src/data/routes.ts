import { ServiceRoute } from '../types/booking';

export const popularRoutes: ServiceRoute[] = [
  {
    id: 'casablanca-marrakech',
    from: 'Casablanca',
    to: 'Marrakech',
    distance: 240,
    duration: '3h00',
    basePrice: 1200,
    popular: true
  },
  {
    id: 'rabat-casablanca',
    from: 'Rabat',
    to: 'Casablanca',
    distance: 90,
    duration: '1h30',
    basePrice: 500,
    popular: true
  },
  {
    id: 'marrakech-essaouira',
    from: 'Marrakech',
    to: 'Essaouira',
    distance: 190,
    duration: '2h45',
    basePrice: 900,
    popular: true
  },
  {
    id: 'casablanca-airport',
    from: 'Casablanca City',
    to: 'Mohammed V Airport',
    distance: 35,
    duration: '45min',
    basePrice: 250,
    popular: true
  },
  {
    id: 'marrakech-ouarzazate',
    from: 'Marrakech',
    to: 'Ouarzazate',
    distance: 200,
    duration: '3h30',
    basePrice: 1000,
    popular: false
  },
  {
    id: 'fez-meknes',
    from: 'Fez',
    to: 'Meknes',
    distance: 60,
    duration: '1h00',
    basePrice: 350,
    popular: false
  },
  {
    id: 'tangier-tetouan',
    from: 'Tangier',
    to: 'Tetouan',
    distance: 65,
    duration: '1h15',
    basePrice: 400,
    popular: false
  },
  {
    id: 'agadir-marrakech',
    from: 'Agadir',
    to: 'Marrakech',
    distance: 250,
    duration: '3h00',
    basePrice: 1200,
    popular: false
  },
  {
    id: 'rabat-airport',
    from: 'Rabat',
    to: 'Rabat-Salé Airport',
    distance: 15,
    duration: '20min',
    basePrice: 150,
    popular: false
  },
  {
    id: 'fez-airport',
    from: 'Fez City',
    to: 'Fez-Saïs Airport',
    distance: 20,
    duration: '25min',
    basePrice: 180,
    popular: false
  },
  {
    id: 'tangier-airport',
    from: 'Tangier City',
    to: 'Tangier Ibn Battouta Airport',
    distance: 25,
    duration: '30min',
    basePrice: 200,
    popular: false
  },
  {
    id: 'agadir-airport',
    from: 'Agadir City',
    to: 'Al Massira Airport',
    distance: 25,
    duration: '30min',
    basePrice: 200,
    popular: false
  }
];