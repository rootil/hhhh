import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import ServicesSection from './components/ServicesSection';
import FleetSection from './components/FleetSection';
import DestinationsSection from './components/DestinationsSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import Chatbot from './components/Chatbot';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <ServicesSection />
        <FleetSection />
        <DestinationsSection />
        <ContactSection />
      </main>
      <Footer />
      <Chatbot />
    </div>
  );
}

export default App;