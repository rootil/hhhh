export interface BookingData {
  id?: string;
  type: 'airport' | 'intercity' | 'hourly';
  pickup: {
    location: string;
    date: string;
    time: string;
    flightNumber?: string;
  };
  destination: string;
  passengers: {
    adults: number;
    children: number;
  };
  luggage: {
    large: number;
    small: number;
  };
  vehicle?: VehicleType;
  options: string[];
  customer: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  price: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  paymentMethod: 'online' | 'cash' | 'partial';
}

export interface VehicleType {
  id: string;
  name: string;
  category: 'standard' | 'premium' | 'luxury';
  capacity: {
    passengers: number;
    luggage: number;
  };
  features: string[];
  pricePerKm: number;
  basePrice: number;
  image: string;
}

export interface ServiceRoute {
  id: string;
  from: string;
  to: string;
  distance: number;
  duration: string;
  basePrice: number;
  popular: boolean;
}