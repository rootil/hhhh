import React from 'react';
import { Plane, MapPin, Clock, Shield, Star, Phone } from 'lucide-react';

const ServicesSection: React.FC = () => {
  const services = [
    {
      icon: Plane,
      title: 'Airport Transfers',
      description: 'Shuttle service to/from airports across Morocco with real-time flight tracking.',
      features: ['Flight tracking', 'Meet & greet', '24/7 service'],
      color: 'text-primary-600 bg-primary-100'
    },
    {
      icon: MapPin,
      title: 'Intercity Travel',
      description: 'Comfortable transportation between major cities throughout Morocco.',
      features: ['Premium vehicles', 'Experienced drivers', 'Fixed rates'],
      color: 'text-accent-600 bg-accent-100'
    },
    {
      icon: Clock,
      title: 'Hourly Service',
      description: 'Vehicle with driver at your disposal for your travels and appointments.',
      features: ['Hourly rates', 'Total flexibility', 'Easy booking'],
      color: 'text-success-600 bg-success-100'
    }
  ];

  const advantages = [
    {
      icon: Shield,
      title: 'Guaranteed Safety',
      description: 'Insured vehicles and licensed professional drivers'
    },
    {
      icon: Star,
      title: 'Premium Service',
      description: 'Air-conditioned vehicles, free WiFi and complimentary water'
    },
    {
      icon: Phone,
      title: '24/7 Support',
      description: 'Phone assistance available at any time'
    }
  ];

  return (
    <section id="services" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Transport Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transport solutions adapted to all your needs, with professional and punctual service throughout Morocco
          </p>
        </div>

        {/* Main services */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
            >
              <div className={`inline-flex p-3 rounded-lg ${service.color} mb-4`}>
                <service.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-sm text-gray-700">
                    <div className="w-1.5 h-1.5 bg-primary-500 rounded-full mr-2"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Advantages */}
        <div className="bg-white rounded-2xl p-8 shadow-md">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">
            Why Choose GOTAXI?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {advantages.map((advantage, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex p-4 bg-primary-100 text-primary-600 rounded-full mb-4">
                  <advantage.icon className="h-8 w-8" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">{advantage.title}</h4>
                <p className="text-gray-600">{advantage.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;