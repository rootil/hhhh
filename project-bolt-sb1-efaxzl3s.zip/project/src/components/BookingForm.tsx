import React, { useState, useEffect, useMemo } from 'react';
import { MapPin, Calendar, Clock, Users, Luggage, Plane, ChevronDown, Sun, Moon, Sunrise, Sunset, Send, Calculator, CheckCircle, AlertCircle, X } from 'lucide-react';

// It's better to move this data to a separate file, e.g., 'src/data/routes.ts'
// This keeps your component cleaner.
const pricingData = {
  'casablanca-mohammed-v-airport': { price: 250, distance: 35 },
  'rabat-rabat-sale-airport': { price: 150, distance: 15 },
  'marrakech-menara-airport': { price: 200, distance: 10 },
  'fez-fez-sais-airport': { price: 180, distance: 20 },
  'tangier-ibn-battouta-airport': { price: 200, distance: 25 },
  'agadir-al-massira-airport': { price: 200, distance: 25 },
  'casablanca-marrakech': { price: 1200, distance: 240 },
  'casablanca-rabat': { price: 500, distance: 90 },
  'casablanca-fez': { price: 1000, distance: 300 },
  'casablanca-tangier': { price: 1200, distance: 340 },
  'casablanca-agadir': { price: 1500, distance: 500 },
  'marrakech-essaouira': { price: 900, distance: 190 },
  'marrakech-ouarzazate': { price: 1000, distance: 200 },
  'marrakech-fez': { price: 1400, distance: 460 },
  'rabat-fez': { price: 800, distance: 200 },
  'rabat-meknes': { price: 600, distance: 140 },
  'fez-meknes': { price: 350, distance: 60 },
  'tangier-tetouan': { price: 400, distance: 65 },
  'agadir-essaouira': { price: 600, distance: 170 }
};

const popularCities = [
  'Casablanca', 'Rabat', 'Marrakech', 'Fez', 'Tangier', 'Agadir', 'Meknes', 'Essaouira',
  'Ouarzazate', 'Tetouan', 'Mohammed V Airport', 'Rabat-Sale Airport', 'Menara Airport',
  'Fez-Sais Airport', 'Ibn Battouta Airport', 'Al Massira Airport'
];

// Helper to format date for display
const getFormattedDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) return 'Today';
    if (date.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
    
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        day: 'numeric',
        month: 'long'
    });
};

const BookingForm: React.FC = () => {
    const [bookingType, setBookingType] = useState<'airport' | 'intercity' | 'hourly'>('airport');
    const [formData, setFormData] = useState({
        pickup: '',
        destination: '',
        date: '',
        time: '',
        flightNumber: '',
        adults: 1,
        children: 0,
        largeLuggage: 1,
        smallLuggage: 1,
        customerName: '',
        customerEmail: '',
        customerPhone: ''
    });

    const [uiState, setUiState] = useState({
        isSubmitting: false,
        estimatedPrice: null as number | null,
        showPriceCalculated: false,
        showDatePicker: false,
        pickupSuggestions: [] as string[],
        destinationSuggestions: [] as string[],
        submissionStatus: 'idle' as 'idle' | 'success' | 'error',
        statusMessage: ''
    });

    const handleInputChange = (field: keyof typeof formData, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (field === 'pickup' || field === 'destination') {
            setUiState(prev => ({ ...prev, estimatedPrice: null, showPriceCalculated: false }));
        }
    };

    const filterCities = (input: string) => {
        if (!input) return [];
        return popularCities.filter(city => city.toLowerCase().includes(input.toLowerCase())).slice(0, 5);
    };

    const handleLocationChange = (field: 'pickup' | 'destination', value: string) => {
        handleInputChange(field, value);
        const suggestions = filterCities(value);
        setUiState(prev => ({ ...prev, [`${field}Suggestions`]: suggestions }));
    };

    const selectSuggestion = (field: 'pickup' | 'destination', city: string) => {
        handleInputChange(field, city);
        setUiState(prev => ({ ...prev, [`${field}Suggestions`]: [] }));
    };
    
    const calculatePrice = () => {
        if (!formData.pickup || !formData.destination) {
            alert('Please enter both pickup and destination locations first.');
            return;
        }
        const pickup = formData.pickup.toLowerCase().trim().replace(/\s+/g, '-');
        const destination = formData.destination.toLowerCase().trim().replace(/\s+/g, '-');
        const routeKey1 = `${pickup}-${destination}`;
        const routeKey2 = `${destination}-${pickup}`;
        const priceInfo = pricingData[routeKey1] || pricingData[routeKey2];

        setUiState(prev => ({
            ...prev,
            estimatedPrice: priceInfo ? priceInfo.price : null,
            showPriceCalculated: true
        }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setUiState(prev => ({ ...prev, isSubmitting: true, submissionStatus: 'idle' }));

        const formAction = "https://formsubmit.co/ilyaselbadaoui156@gmail.com"; // <-- IMPORTANT: REPLACE WITH YOUR EMAIL

        try {
            const response = await fetch(formAction, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body: JSON.stringify({
                    ...formData,
                    bookingType,
                    estimatedPrice: uiState.estimatedPrice ? `${uiState.estimatedPrice} MAD` : 'N/A',
                    _subject: `New GOTAXI Booking Request - ${bookingType.toUpperCase()}`,
                    _replyto: formData.customerEmail,
                })
            });

            if (response.ok) {
                setUiState(prev => ({ ...prev, submissionStatus: 'success', statusMessage: 'Your request has been sent successfully!' }));
                // Reset form after a delay
                setTimeout(() => {
                    setFormData({
                        pickup: '', destination: '', date: '', time: '', flightNumber: '',
                        adults: 1, children: 0, largeLuggage: 1, smallLuggage: 1,
                        customerName: '', customerEmail: '', customerPhone: ''
                    });
                    setUiState(prev => ({...prev, submissionStatus: 'idle', isSubmitting: false, showPriceCalculated: false, estimatedPrice: null}));
                }, 5000);
            } else {
                throw new Error('Form submission failed');
            }
        } catch (error) {
            console.error('Submission error:', error);
            setUiState(prev => ({ ...prev, submissionStatus: 'error', statusMessage: 'An error occurred. Please try again.' }));
        } finally {
            // Let the success/error message display before resetting submitting state
            if (uiState.submissionStatus !== 'success') {
                setUiState(prev => ({ ...prev, isSubmitting: false }));
            }
        }
    };
    
    // Memoize options to prevent recalculation on every render
    const timeOptions = useMemo(() => {
        const options = [];
        for (let hour = 0; hour < 24; hour++) {
            for (let minute = 0; minute < 60; minute += 15) {
                options.push(`${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`);
            }
        }
        return options;
    }, []);

    return (
        <>
            {uiState.submissionStatus !== 'idle' && (
                <div className={`fixed top-4 right-4 z-50 max-w-md p-4 rounded-lg shadow-lg ${uiState.submissionStatus === 'success' ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                    <div className="flex items-start space-x-3">
                        {uiState.submissionStatus === 'success' ? <CheckCircle className="h-6 w-6 text-green-600" /> : <AlertCircle className="h-6 w-6 text-red-600" />}
                        <div>
                            <p className={`text-sm font-medium ${uiState.submissionStatus === 'success' ? 'text-green-800' : 'text-red-800'}`}>{uiState.submissionStatus === 'success' ? 'Success!' : 'Error'}</p>
                            <p className={`text-sm mt-1 ${uiState.submissionStatus === 'success' ? 'text-green-700' : 'text-red-700'}`}>{uiState.statusMessage}</p>
                        </div>
                        <button onClick={() => setUiState(prev => ({ ...prev, submissionStatus: 'idle' }))} className={`flex-shrink-0 ${uiState.submissionStatus === 'success' ? 'text-green-400' : 'text-red-400'}`}><X className="h-5 w-5" /></button>
                    </div>
                </div>
            )}
            <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
                <div className="mb-6">
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">Book Your Transfer</h2>
                    <p className="text-gray-600">Fast and comfortable service, available 24/7</p>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-6">
                    {[ { id: 'airport', label: 'Airport', icon: Plane }, { id: 'intercity', label: 'Intercity', icon: MapPin }, { id: 'hourly', label: 'Hourly', icon: Clock } ].map(({ id, label, icon: Icon }) => (
                        <button key={id} onClick={() => setBookingType(id as any)} className={`flex flex-col items-center p-3 rounded-lg border-2 transition-all ${bookingType === id ? 'border-primary-500 bg-primary-50' : 'border-gray-200 hover:border-gray-300'}`}>
                            <Icon className="h-5 w-5 mb-1" />
                            <span className="text-sm font-medium">{label}</span>
                        </button>
                    ))}
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Location Inputs */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Pickup */}
                        <div className="relative">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Pickup Location</label>
                            <div className="relative">
                                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                <input type="text" value={formData.pickup} onChange={(e) => handleLocationChange('pickup', e.target.value)} onFocus={() => setUiState(prev => ({...prev, showPickupSuggestions: true}))} onBlur={() => setTimeout(() => setUiState(prev => ({...prev, showPickupSuggestions: false})), 150)} placeholder="Departure address" className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" required />
                                {uiState.showPickupSuggestions && uiState.pickupSuggestions.length > 0 && (
                                    <div className="absolute z-10 w-full mt-1 bg-white border rounded-lg shadow-lg max-h-60 overflow-y-auto">
                                        {uiState.pickupSuggestions.map(city => <button key={city} type="button" onMouseDown={() => selectSuggestion('pickup', city)} className="w-full text-left px-4 py-2 hover:bg-gray-100">{city}</button>)}
                                    </div>
                                )}
                            </div>
                        </div>
                        {/* Destination */}
                        <div className="relative">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Destination</label>
                            <div className="relative">
                                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                <input type="text" value={formData.destination} onChange={(e) => handleLocationChange('destination', e.target.value)} onFocus={() => setUiState(prev => ({...prev, showDestinationSuggestions: true}))} onBlur={() => setTimeout(() => setUiState(prev => ({...prev, showDestinationSuggestions: false})), 150)} placeholder="Arrival address" className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500" required />
                                {uiState.showDestinationSuggestions && uiState.destinationSuggestions.length > 0 && (
                                    <div className="absolute z-10 w-full mt-1 bg-white border rounded-lg shadow-lg max-h-60 overflow-y-auto">
                                        {uiState.destinationSuggestions.map(city => <button key={city} type="button" onMouseDown={() => selectSuggestion('destination', city)} className="w-full text-left px-4 py-2 hover:bg-gray-100">{city}</button>)}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Price Estimation */}
                    <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
                        <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-gray-900">Price Estimation</h3>
                            <button type="button" onClick={calculatePrice} className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg font-medium flex items-center space-x-2">
                                <Calculator className="h-4 w-4" />
                                <span>Calculate Price</span>
                            </button>
                        </div>
                        {uiState.showPriceCalculated && (
                             <div className="mt-3 bg-white rounded-lg p-4 border">
                                {uiState.estimatedPrice ? (
                                    <p className="text-lg">Estimated Price: <span className="font-bold text-green-600">{uiState.estimatedPrice} MAD</span></p>
                                ) : (
                                    <p>This route requires a custom quote. Please submit your request.</p>
                                )}
                            </div>
                        )}
                    </div>

                    {/* Date & Time */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                            <input type="date" id="date" value={formData.date} onChange={(e) => handleInputChange('date', e.target.value)} min={new Date().toISOString().split('T')[0]} className="w-full py-3 px-4 border border-gray-300 rounded-lg" required />
                            {formData.date && <p className="text-sm text-gray-600 mt-1">{getFormattedDate(formData.date)}</p>}
                        </div>
                        <div>
                            <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-2">Departure Time</label>
                            <select id="time" value={formData.time} onChange={(e) => handleInputChange('time', e.target.value)} className="w-full py-3 px-4 border border-gray-300 rounded-lg" required>
                                <option value="">Select time</option>
                                {timeOptions.map(time => <option key={time} value={time}>{time}</option>)}
                            </select>
                        </div>
                    </div>

                    {/* Flight Number */}
                    {bookingType === 'airport' && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Flight Number (optional)</label>
                            <div className="relative">
                                <Plane className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                <input type="text" value={formData.flightNumber} onChange={(e) => handleInputChange('flightNumber', e.target.value)} placeholder="e.g. AT123" className="w-full pl-10 pr-4 py-3 border rounded-lg" />
                            </div>
                        </div>
                    )}

                    {/* Passengers & Luggage */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Adults</label>
                            <select value={formData.adults} onChange={e => handleInputChange('adults', +e.target.value)} className="w-full py-3 px-4 border rounded-lg">
                                {[...Array(8).keys()].map(i => <option key={i+1} value={i+1}>{i+1}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Children</label>
                            <select value={formData.children} onChange={e => handleInputChange('children', +e.target.value)} className="w-full py-3 px-4 border rounded-lg">
                                {[...Array(5).keys()].map(i => <option key={i} value={i}>{i}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Large Bags</label>
                            <select value={formData.largeLuggage} onChange={e => handleInputChange('largeLuggage', +e.target.value)} className="w-full py-3 px-4 border rounded-lg">
                                {[...Array(7).keys()].map(i => <option key={i} value={i}>{i}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Cabin Bags</label>
                            <select value={formData.smallLuggage} onChange={e => handleInputChange('smallLuggage', +e.target.value)} className="w-full py-3 px-4 border rounded-lg">
                                {[...Array(7).keys()].map(i => <option key={i} value={i}>{i}</option>)}
                            </select>
                        </div>
                    </div>

                    {/* Contact Information */}
                    <div className="bg-gray-50 rounded-xl p-6 space-y-4">
                        <h3 className="text-lg font-semibold text-gray-900">Your Contact Information</h3>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                            <input type="text" value={formData.customerName} onChange={(e) => handleInputChange('customerName', e.target.value)} placeholder="Your full name" className="w-full px-4 py-3 border rounded-lg" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                            <input type="tel" value={formData.customerPhone} onChange={(e) => handleInputChange('customerPhone', e.target.value)} placeholder="+212 6XX XXX XXX" className="w-full px-4 py-3 border rounded-lg" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                            <input type="email" value={formData.customerEmail} onChange={(e) => handleInputChange('customerEmail', e.target.value)} placeholder="your@email.com" className="w-full px-4 py-3 border rounded-lg" required />
                        </div>
                    </div>

                    <button type="submit" disabled={uiState.isSubmitting} className="w-full bg-primary-600 hover:bg-primary-700 disabled:bg-gray-400 text-white font-semibold py-4 px-6 rounded-lg flex items-center justify-center space-x-2">
                        {uiState.isSubmitting ? (
                            <>
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                                <span>Sending...</span>
                            </>
                        ) : (
                            <>
                                <Send className="h-5 w-5" />
                                <span>Send Booking Request</span>
                            </>
                        )}
                    </button>
                </form>
            </div>
        </>
    );
};

export default BookingForm;