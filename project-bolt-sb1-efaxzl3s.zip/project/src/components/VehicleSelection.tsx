import React from 'react';
import { Check, Users, Luggage, Wifi, Car } from 'lucide-react';
import { VehicleType } from '../types/booking';
import { vehicles } from '../data/vehicles';

interface VehicleSelectionProps {
  passengers: number;
  luggage: number;
  onVehicleSelect: (vehicle: VehicleType, price: number) => void;
  onBack: () => void;
}

const VehicleSelection: React.FC<VehicleSelectionProps> = ({
  passengers,
  luggage,
  onVehicleSelect,
  onBack
}) => {
  const calculatePrice = (vehicle: VehicleType, distance: number = 50) => {
    return vehicle.basePrice + (vehicle.pricePerKm * distance);
  };

  const isVehicleSuitable = (vehicle: VehicleType) => {
    return vehicle.capacity.passengers >= passengers && vehicle.capacity.luggage >= luggage;
  };

  const filteredVehicles = vehicles.filter(isVehicleSuitable);

  return (
    <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
      <div className="mb-6">
        <button
          onClick={onBack}
          className="text-primary-600 hover:text-primary-700 font-medium mb-4 flex items-center"
        >
          ← Back
        </button>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Choose your vehicle</h2>
        <p className="text-gray-600">
          Vehicles suitable for {passengers} passenger{passengers > 1 ? 's' : ''} and {luggage} bag{luggage > 1 ? 's' : ''}
        </p>
      </div>

      <div className="space-y-4">
        {filteredVehicles.map((vehicle) => {
          const price = calculatePrice(vehicle);
          return (
            <div
              key={vehicle.id}
              className="border border-gray-200 rounded-xl p-6 hover:border-primary-300 hover:shadow-md transition-all duration-200 cursor-pointer group"
              onClick={() => onVehicleSelect(vehicle, price)}
            >
              <div className="flex flex-col md:flex-row gap-6">
                {/* Vehicle image */}
                <div className="md:w-1/3">
                  <img
                    src={vehicle.image}
                    alt={vehicle.name}
                    className="w-full h-48 md:h-32 object-cover rounded-lg"
                  />
                </div>

                {/* Vehicle details */}
                <div className="md:w-2/3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-semibold text-gray-900">{vehicle.name}</h3>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        vehicle.category === 'luxury' ? 'bg-accent-100 text-accent-700' :
                        vehicle.category === 'premium' ? 'bg-primary-100 text-primary-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {vehicle.category === 'luxury' ? 'Luxury' :
                         vehicle.category === 'premium' ? 'Premium' : 'Standard'}
                      </span>
                    </div>

                    {/* Capacity */}
                    <div className="flex items-center space-x-4 mb-3 text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span className="text-sm">{vehicle.capacity.passengers} passengers</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Luggage className="h-4 w-4" />
                        <span className="text-sm">{vehicle.capacity.luggage} bags</span>
                      </div>
                    </div>

                    {/* Features */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {vehicle.features.map((feature, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full"
                        >
                          <Check className="h-3 w-3 mr-1" />
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Price and action */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl font-bold text-gray-900">{price} MAD</span>
                      <span className="text-gray-500 text-sm ml-1">Total</span>
                    </div>
                    <button className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2 rounded-lg font-medium transition-colors duration-200 group-hover:shadow-md">
                      Select
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredVehicles.length === 0 && (
        <div className="text-center py-12">
          <Car className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No vehicles available</h3>
          <p className="text-gray-600">
            Please adjust the number of passengers or bags to see available vehicles.
          </p>
        </div>
      )}
    </div>
  );
};

export default VehicleSelection;