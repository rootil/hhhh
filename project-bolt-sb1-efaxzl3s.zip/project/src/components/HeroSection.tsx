import React, { useState } from 'react';
import { Star, CheckCircle, Users } from 'lucide-react';
import BookingForm from './BookingForm';
import VehicleSelection from './VehicleSelection';
import { VehicleType } from '../types/booking';

const HeroSection: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<'booking' | 'vehicle'>('booking');
  const [bookingData, setBookingData] = useState<any>(null);

  const handleBookingStart = (data: any) => {
    setBookingData(data);
    setCurrentStep('vehicle');
  };

  const handleVehicleSelect = (vehicle: VehicleType, price: number) => {
    // Here you would typically proceed to customer details and payment
    console.log('Selected vehicle:', vehicle, 'Price:', price);
    alert(`Vehicle selected: ${vehicle.name} - ${price} MAD`);
  };

  const handleBack = () => {
    setCurrentStep('booking');
  };

  const stats = [
    { icon: Users, label: 'Happy Customers', value: '10,000+' },
    { icon: CheckCircle, label: 'Completed Transfers', value: '50,000+' },
    { icon: Star, label: 'Average Rating', value: '4.9/5' }
  ];

  return (
    <section id="home" className="relative min-h-screen bg-gradient-to-br from-primary-50 via-white to-primary-100 pt-24">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary-200 rounded-full opacity-20"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-accent-200 rounded-full opacity-20"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left column - Hero content */}
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              Premium Transport
              <span className="block text-primary-600">Across Morocco</span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-2xl">
              Book your transfer online and travel with peace of mind. 
              Professional service, premium vehicles and experienced drivers throughout Morocco.
            </p>

            {/* Trust indicators */}
            <div className="grid grid-cols-3 gap-6 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="inline-flex p-3 bg-white rounded-full shadow-md mb-2">
                    <stat.icon className="h-6 w-6 text-primary-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Features */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-4 mb-8">
              {[
                '24/7 Service',
                'Secure Payment',
                'Insured Vehicles',
                'Licensed Drivers'
              ].map((feature, index) => (
                <span
                  key={index}
                  className="inline-flex items-center px-3 py-1.5 bg-white text-sm font-medium text-gray-700 rounded-full shadow-sm"
                >
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  {feature}
                </span>
              ))}
            </div>
          </div>

          {/* Right column - Booking form */}
          <div className="lg:pl-8">
            {currentStep === 'booking' ? (
              <BookingForm onBookingStart={handleBookingStart} />
            ) : (
              <VehicleSelection
                passengers={bookingData?.adults + bookingData?.children || 1}
                luggage={bookingData?.largeLuggage + bookingData?.smallLuggage || 1}
                onVehicleSelect={handleVehicleSelect}
                onBack={handleBack}
              />
            )}
          </div>
        </div>
      </div>

      {/* Bottom wave decoration */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          className="w-full h-16 text-gray-50"
          preserveAspectRatio="none"
          viewBox="0 0 1200 120"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M0,0V46.29c0,0,48.5-34.5,120-34.5s120,34.5,120,34.5,48.5-34.5,120-34.5s120,34.5,120,34.5,48.5-34.5,120-34.5s120,34.5,120,34.5,48.5-34.5,120-34.5s120,34.5,120,34.5,48.5-34.5,120-34.5s120,34.5,120,34.5,48.5-34.5,120-34.5s120,34.5,120,34.5V0Z"
            fill="currentColor"
          ></path>
        </svg>
      </div>
    </section>
  );
};

export default HeroSection;