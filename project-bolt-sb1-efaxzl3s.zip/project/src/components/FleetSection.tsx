import React from 'react';
import { Users, Luggage, Check, Star, Shield, Award } from 'lucide-react';
import { vehicles } from '../data/vehicles';

const FleetSection: React.FC = () => {
  const scrollToBooking = () => {
    const bookingSection = document.getElementById('home');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'luxury':
        return 'bg-gradient-to-r from-amber-100 to-yellow-100 text-amber-800 border-amber-200';
      case 'premium':
        return 'bg-gradient-to-r from-blue-100 to-indigo-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gradient-to-r from-gray-100 to-slate-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'luxury':
        return <Award className="h-4 w-4" />;
      case 'premium':
        return <Star className="h-4 w-4" />;
      default:
        return <Shield className="h-4 w-4" />;
    }
  };

  return (
    <section id="fleet" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Our Premium Fleet
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Choose from our carefully selected collection of modern, comfortable, and well-maintained vehicles. 
            Each vehicle comes with a professional driver and premium amenities for your journey across Morocco.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8 mb-16">
          {vehicles.map((vehicle, index) => (
            <div
              key={vehicle.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 group"
            >
              {/* Vehicle image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={vehicle.image}
                  alt={vehicle.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              {/* Vehicle details */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-primary-600 transition-colors">
                    {vehicle.name}
                  </h3>
                  <span className={`px-3 py-1.5 rounded-full text-sm font-semibold border flex items-center space-x-1 ${getCategoryColor(vehicle.category)}`}>
                    {getCategoryIcon(vehicle.category)}
                    <span className="capitalize">{vehicle.category}</span>
                  </span>
                </div>

                {/* Capacity */}
                <div className="flex items-center space-x-6 mb-6 text-gray-600">
                  <div className="flex items-center space-x-2 bg-gray-50 px-3 py-2 rounded-lg">
                    <Users className="h-5 w-5 text-primary-600" />
                    <span className="font-medium">{vehicle.capacity.passengers} passengers</span>
                  </div>
                  <div className="flex items-center space-x-2 bg-gray-50 px-3 py-2 rounded-lg">
                    <Luggage className="h-5 w-5 text-accent-600" />
                    <span className="font-medium">{vehicle.capacity.luggage} bags</span>
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-2 mb-6">
                  <h4 className="font-semibold text-gray-900 text-sm uppercase tracking-wide">Included Features</h4>
                  <div className="grid grid-cols-1 gap-2">
                    {vehicle.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center text-sm text-gray-700">
                        <Check className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Pricing */}
                <div className="border-t border-gray-100 pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="text-2xl font-bold text-gray-900">
                        {vehicle.basePrice} MAD
                        <span className="text-sm font-normal text-gray-500 ml-1">base</span>
                      </div>
                      <div className="text-sm text-gray-600">
                        + {vehicle.pricePerKm} MAD/km
                      </div>
                    </div>
                    <button 
                      onClick={scrollToBooking}
                      className="bg-gradient-to-r from-primary-600 to-primary-700 hover:from-primary-700 hover:to-primary-800 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                    >
                      Book Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Fleet advantages */}
        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl">
          <h3 className="text-3xl font-bold text-gray-900 text-center mb-8">
            Every Vehicle in Our Fleet Includes
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { icon: Shield, label: 'Full Insurance Coverage', color: 'text-green-600' },
              { icon: Star, label: 'Professional Drivers', color: 'text-blue-600' },
              { icon: Check, label: '24/7 Road Assistance', color: 'text-purple-600' },
              { icon: Award, label: 'Premium Maintenance', color: 'text-amber-600' }
            ].map((item, index) => (
              <div key={index} className="group">
                <div className={`inline-flex p-4 rounded-2xl bg-gray-50 group-hover:bg-gray-100 transition-colors duration-200 mb-3 ${item.color}`}>
                  <item.icon className="h-8 w-8" />
                </div>
                <h4 className="font-semibold text-gray-900 text-sm">{item.label}</h4>
              </div>
            ))}
          </div>
          
          <div className="mt-8 pt-8 border-t border-gray-100">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
              {[
                'Air conditioning in all vehicles',
                'Complimentary WiFi access',
                'Free bottled water',
                'GPS navigation systems',
                'Regular safety inspections',
                'Clean and sanitized interiors',
                'Fuel included in pricing',
                'Meet & greet service available'
              ].map((item, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Call to action */}
        <div className="mt-12 text-center">
          <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              Need Help Choosing the Right Vehicle?
            </h3>
            <p className="text-primary-100 mb-6 max-w-2xl mx-auto">
              Our team can help you select the perfect vehicle based on your group size, luggage requirements, and travel preferences.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={scrollToBooking}
                className="bg-white text-primary-600 hover:bg-gray-50 px-8 py-3 rounded-xl font-semibold transition-colors duration-200"
              >
                Get Personalized Recommendation
              </button>
              <button 
                onClick={() => {
                  const contactSection = document.getElementById('contact');
                  if (contactSection) {
                    contactSection.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="border-2 border-white text-white hover:bg-white hover:text-primary-600 px-8 py-3 rounded-xl font-semibold transition-all duration-200"
              >
                Contact Our Team
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FleetSection;