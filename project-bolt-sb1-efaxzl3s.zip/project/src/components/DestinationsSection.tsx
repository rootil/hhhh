import React from 'react';
import { MapPin, Clock, ArrowRight } from 'lucide-react';
import { popularRoutes } from '../data/routes';

const DestinationsSection: React.FC = () => {
  const scrollToBooking = () => {
    const bookingSection = document.getElementById('home');
    if (bookingSection) {
      bookingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="destinations" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Popular Destinations
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Most requested routes with fixed and transparent rates throughout Morocco
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {popularRoutes.map((route) => (
            <div
              key={route.id}
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2 text-gray-700">
                    <MapPin className="h-5 w-5 text-primary-600" />
                    <span className="font-medium">{route.from}</span>
                  </div>
                  <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-primary-600 transition-colors" />
                  <div className="flex items-center space-x-2 text-gray-700">
                    <MapPin className="h-5 w-5 text-accent-600" />
                    <span className="font-medium">{route.to}</span>
                  </div>
                </div>
                {route.popular && (
                  <span className="bg-success-100 text-success-700 px-2 py-1 rounded-full text-xs font-medium">
                    Popular
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <span>Distance: {route.distance} km</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{route.duration}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-2xl font-bold text-gray-900">{route.basePrice} MAD</span>
                  <span className="text-gray-500 text-sm ml-1">from</span>
                </div>
                <button 
                  onClick={scrollToBooking}
                  className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2 rounded-lg font-medium transition-all duration-200 group-hover:shadow-md"
                >
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Custom route section */}
        <div className="mt-12 bg-white rounded-2xl p-8 shadow-md text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Destination not listed?
          </h3>
          <p className="text-gray-600 mb-6">
            We serve all destinations throughout Morocco. Contact us for a personalized quote.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={scrollToBooking}
              className="bg-primary-600 hover:bg-primary-700 text-white px-8 py-3 rounded-lg font-medium transition-colors duration-200"
            >
              Request Quote
            </button>
            <button 
              onClick={() => {
                const contactSection = document.getElementById('contact');
                if (contactSection) {
                  contactSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="border border-primary-600 text-primary-600 hover:bg-primary-50 px-8 py-3 rounded-lg font-medium transition-colors duration-200"
            >
              Contact Us
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DestinationsSection;