import React from 'react';
import { Car, Shield, Clock, MapPin, Users, Wifi } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: <Car className="text-primary-500" size={40} />,
      title: "Airport Transfers",
      description: "Reliable transfers to and from Marrakech Menara Airport and Essaouira Airport"
    },
    {
      icon: <MapPin className="text-primary-500" size={40} />,
      title: "City Tours",
      description: "Explore the beautiful cities of Marrakech and Essaouira with our guided tours"
    },
    {
      icon: <Clock className="text-primary-500" size={40} />,
      title: "24/7 Service",
      description: "Round-the-clock availability for all your transportation needs"
    },
    {
      icon: <Users className="text-primary-500" size={40} />,
      title: "Group Transport",
      description: "Comfortable vehicles for groups up to 8 passengers"
    },
    {
      icon: <Shield className="text-primary-500" size={40} />,
      title: "Safe & Insured",
      description: "All our vehicles are fully insured with professional licensed drivers"
    },
    {
      icon: <Wifi className="text-primary-500" size={40} />,
      title: "Modern Comfort",
      description: "Air-conditioned vehicles with WiFi and phone charging facilities"
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover our comprehensive range of transportation services designed to meet all your travel needs between Marrakech and Essaouira.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="card p-8 text-center group">
              <div className="mb-6 flex justify-center transform group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button className="btn-primary text-lg px-8 py-4">
            Book Your Service
          </button>
        </div>
      </div>
    </section>
  );
};

export default Services;