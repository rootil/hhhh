import React from 'react';
import { Award, Users, Clock, Shield } from 'lucide-react';

const About = () => {
  const stats = [
    {
      icon: <Users className="text-primary-500" size={32} />,
      number: "10,000+",
      label: "Happy Customers"
    },
    {
      icon: <Clock className="text-primary-500" size={32} />,
      number: "5+",
      label: "Years Experience"
    },
    {
      icon: <Award className="text-primary-500" size={32} />,
      number: "4.9/5",
      label: "Customer Rating"
    },
    {
      icon: <Shield className="text-primary-500" size={32} />,
      number: "100%",
      label: "Safety Record"
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-800 mb-6">About Taxiaeoro</h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Taxiaeoro has been providing premium transportation services between Marrakech and Essaouira for over 5 years. We pride ourselves on delivering safe, comfortable, and reliable journeys for both tourists and locals.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Our team of professional drivers knows the route like the back of their hand, ensuring you reach your destination safely and on time. We maintain a modern fleet of well-maintained vehicles equipped with all the amenities you need for a comfortable journey.
            </p>
            
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="flex justify-center mb-3">
                    {stat.icon}
                  </div>
                  <div className="text-2xl font-bold text-gray-800 mb-1">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.pexels.com/photos/1118448/pexels-photo-1118448.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
              alt="Professional taxi service"
              className="rounded-xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -left-6 bg-primary-500 text-white p-6 rounded-xl shadow-xl">
              <div className="text-2xl font-bold">24/7</div>
              <div className="text-sm">Available</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;