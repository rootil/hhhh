import React, { useState } from 'react';
import { Menu, X, Phone, Mail } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">T</span>
            </div>
            <span className="text-2xl font-bold text-gray-800">Taxiaeoro</span>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-700 hover:text-primary-500 transition-colors font-medium">Home</a>
            <a href="#services" className="text-gray-700 hover:text-primary-500 transition-colors font-medium">Services</a>
            <a href="#pricing" className="text-gray-700 hover:text-primary-500 transition-colors font-medium">Pricing</a>
            <a href="#about" className="text-gray-700 hover:text-primary-500 transition-colors font-medium">About</a>
            <a href="#contact" className="text-gray-700 hover:text-primary-500 transition-colors font-medium">Contact</a>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Phone size={16} />
              <span>+212 661-234567</span>
            </div>
            <button className="btn-primary">Book Now</button>
          </div>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-4">
              <a href="#home" className="text-gray-700 hover:text-primary-500 transition-colors">Home</a>
              <a href="#services" className="text-gray-700 hover:text-primary-500 transition-colors">Services</a>
              <a href="#pricing" className="text-gray-700 hover:text-primary-500 transition-colors">Pricing</a>
              <a href="#about" className="text-gray-700 hover:text-primary-500 transition-colors">About</a>
              <a href="#contact" className="text-gray-700 hover:text-primary-500 transition-colors">Contact</a>
              <div className="flex items-center space-x-2 text-sm text-gray-600 pt-2">
                <Phone size={16} />
                <span>+212 661-234567</span>
              </div>
              <button className="btn-primary w-full">Book Now</button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;