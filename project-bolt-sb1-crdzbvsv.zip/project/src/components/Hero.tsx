import React from 'react';
import { MapPin, Clock, Shield, Star } from 'lucide-react';
import BookingForm from './BookingForm';

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/1118448/pexels-photo-1118448.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop)',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      </div>
      
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-white">
            <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Professional Taxi Services
              <span className="block text-primary-400">Marrakech - Essaouira</span>
            </h1>
            <p className="text-xl mb-8 text-gray-200 leading-relaxed">
              Experience comfortable, reliable, and safe transportation between Marrakech and Essaouira with Taxiaeoro. Your journey, our priority.
            </p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="flex items-center space-x-2">
                <Shield className="text-primary-400" size={20} />
                <span className="text-sm">Safe & Secure</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="text-primary-400" size={20} />
                <span className="text-sm">24/7 Service</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="text-primary-400" size={20} />
                <span className="text-sm">Door to Door</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="text-primary-400" size={20} />
                <span className="text-sm">5-Star Rated</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="btn-primary text-lg px-8 py-4">
                Book Your Ride
              </button>
              <button className="border-2 border-white text-white hover:bg-white hover:text-gray-800 font-semibold py-4 px-8 rounded-lg transition-all duration-300">
                Call Now: +212 661-234567
              </button>
            </div>
          </div>

          <div className="lg:block">
            <BookingForm />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;