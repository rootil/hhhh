import React from 'react';
import { Phone, Mail, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">T</span>
              </div>
              <span className="text-xl font-bold">Taxiaeoro</span>
            </div>
            <p className="text-gray-300 mb-4">
              Your trusted partner for comfortable and reliable transportation between Marrakech and Essaouira.
            </p>
            <div className="flex space-x-4">
              <Facebook className="text-gray-400 hover:text-primary-400 cursor-pointer transition-colors" size={20} />
              <Instagram className="text-gray-400 hover:text-primary-400 cursor-pointer transition-colors" size={20} />
              <Twitter className="text-gray-400 hover:text-primary-400 cursor-pointer transition-colors" size={20} />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-300 hover:text-primary-400 transition-colors">Home</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-primary-400 transition-colors">Services</a></li>
              <li><a href="#pricing" className="text-gray-300 hover:text-primary-400 transition-colors">Pricing</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-primary-400 transition-colors">About</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-primary-400 transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              <li className="text-gray-300">Airport Transfers</li>
              <li className="text-gray-300">City Tours</li>
              <li className="text-gray-300">Group Transport</li>
              <li className="text-gray-300">24/7 Service</li>
              <li className="text-gray-300">Custom Routes</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone size={16} className="text-primary-400" />
                <span className="text-gray-300">+212 661-234567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={16} className="text-primary-400" />
                <span className="text-gray-300">info@taxiaeoro.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin size={16} className="text-primary-400" />
                <span className="text-gray-300">Marrakech - Essaouira</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 Taxiaeoro. All rights reserved. | Professional taxi services in Morocco.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;