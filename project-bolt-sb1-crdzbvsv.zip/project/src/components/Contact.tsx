import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Contact Us</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to book your ride? Get in touch with us through any of the following methods.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="card p-6 text-center">
            <div className="flex justify-center mb-4">
              <Phone className="text-primary-500" size={32} />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Phone</h3>
            <p className="text-gray-600">+212 661-234567</p>
            <p className="text-gray-600">+212 524-123456</p>
          </div>

          <div className="card p-6 text-center">
            <div className="flex justify-center mb-4">
              <Mail className="text-primary-500" size={32} />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Email</h3>
            <p className="text-gray-600">info@taxiaeoro.com</p>
            <p className="text-gray-600">booking@taxiaeoro.com</p>
          </div>

          <div className="card p-6 text-center">
            <div className="flex justify-center mb-4">
              <MapPin className="text-primary-500" size={32} />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Location</h3>
            <p className="text-gray-600">Marrakech, Morocco</p>
            <p className="text-gray-600">Essaouira, Morocco</p>
          </div>

          <div className="card p-6 text-center">
            <div className="flex justify-center mb-4">
              <Clock className="text-primary-500" size={32} />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Hours</h3>
            <p className="text-gray-600">24/7 Service</p>
            <p className="text-gray-600">Always Available</p>
          </div>
        </div>

        <div className="max-w-2xl mx-auto card p-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Send us a Message</h3>
          <form className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="Your full name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                <input
                  type="tel"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="+212 6XX-XXXXXX"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="your@email.com"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
              <textarea
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="Tell us about your transportation needs..."
              ></textarea>
            </div>
            
            <button type="submit" className="btn-primary w-full text-lg py-4">
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;