import React from 'react';
import { Check, Star } from 'lucide-react';

const Pricing = () => {
  const routes = [
    {
      from: "Marrakech",
      to: "Essaouira",
      distance: "180 km",
      duration: "2.5 hours",
      price: "800 MAD",
      popular: true
    },
    {
      from: "Essaouira",
      to: "Marrakech",
      distance: "180 km", 
      duration: "2.5 hours",
      price: "800 MAD",
      popular: true
    },
    {
      from: "Marrakech Airport",
      to: "Essaouira",
      distance: "190 km",
      duration: "3 hours",
      price: "900 MAD",
      popular: false
    },
    {
      from: "Essaouira",
      to: "Marrakech Airport",
      distance: "190 km",
      duration: "3 hours", 
      price: "900 MAD",
      popular: false
    }
  ];

  const features = [
    "Professional licensed driver",
    "Air-conditioned vehicle",
    "Door-to-door service",
    "Free WiFi",
    "Phone charging ports",
    "Bottled water included",
    "24/7 customer support",
    "Flight tracking (airport transfers)"
  ];

  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Transparent Pricing</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            No hidden fees, no surprises. Our competitive rates include all taxes and fees.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {routes.map((route, index) => (
            <div key={index} className={`card p-6 relative ${route.popular ? 'ring-2 ring-primary-500' : ''}`}>
              {route.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary-500 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center">
                    <Star size={14} className="mr-1" />
                    Popular
                  </span>
                </div>
              )}
              
              <div className="text-center">
                <h3 className="font-semibold text-gray-800 mb-2">{route.from}</h3>
                <div className="text-2xl text-primary-500 mb-2">↓</div>
                <h3 className="font-semibold text-gray-800 mb-4">{route.to}</h3>
                
                <div className="text-3xl font-bold text-primary-500 mb-4">{route.price}</div>
                
                <div className="text-sm text-gray-600 space-y-1">
                  <p>{route.distance}</p>
                  <p>{route.duration}</p>
                </div>
                
                <button className="btn-primary w-full mt-4">
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="card p-8">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">What's Included</h3>
            <div className="grid md:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <Check className="text-primary-500 flex-shrink-0" size={20} />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">Need a custom quote for multiple stops or special requirements?</p>
          <button className="btn-secondary">
            Contact Us for Custom Pricing
          </button>
        </div>
      </div>
    </section>
  );
};

export default Pricing;